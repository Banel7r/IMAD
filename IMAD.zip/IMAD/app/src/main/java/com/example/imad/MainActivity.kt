package com.example.lifehackmythquiz

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    private val logTag = "LifeHackMythQuiz"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.d(logTag, "App started successfully")

        setContent {
            LifeHackTheme {
                LifeHackApp()
            }
        }
    }
}

data class FlashcardQuestion(
    val statement: String,
    val isHack: Boolean,
    val explanation: String
)

data class UserAnswer(
    val question: FlashcardQuestion,
    val selectedAnswer: Boolean,
    val isCorrect: Boolean
)

enum class AppScreen {
    WELCOME,
    QUESTION,
    SCORE,
    REVIEW
}

@Composable
fun LifeHackTheme(content: @Composable () -> Unit) {
    val colourScheme = lightColorScheme(
        primary = Color(0xFF2563EB),
        secondary = Color(0xFF16A34A),
        background = Color(0xFFF8FAFC),
        surface = Color.White
    )

    MaterialTheme(
        colorScheme = colourScheme,
        content = content
    )
}

@Composable
fun LifeHackApp() {
    val questions = remember {
        listOf(
            FlashcardQuestion(
                statement = "Putting your phone in rice is the best way to fix water damage.",
                isHack = false,
                explanation = "This is mostly a myth. Rice does not properly remove moisture from inside a phone. It is safer to switch the phone off and take it to a technician."
            ),
            FlashcardQuestion(
                statement = "Using strong, unique passwords for each account helps protect your online identity.",
                isHack = true,
                explanation = "This is a real hack. Unique passwords reduce the risk of one hacked account affecting all your other accounts."
            ),
            FlashcardQuestion(
                statement = "Charging your phone overnight always destroys the battery immediately.",
                isHack = false,
                explanation = "This is an urban myth. Modern phones manage charging better, although keeping the battery cool and avoiding constant 100% charging can help battery health."
            ),
            FlashcardQuestion(
                statement = "Turning on two-factor authentication gives your account extra protection.",
                isHack = true,
                explanation = "This is a useful security hack. Two-factor authentication adds another step before someone can access your account."
            ),
            FlashcardQuestion(
                statement = "Incognito mode makes you completely invisible online.",
                isHack = false,
                explanation = "This is a myth. Incognito mode mainly hides browsing history on your device, but websites, networks, and service providers may still track activity."
            ),
            FlashcardQuestion(
                statement = "Writing down important tasks before sleeping can help you remember them the next day.",
                isHack = true,
                explanation = "This is a practical productivity hack. It helps clear your mind and creates a simple plan for the next day."
            ),
            FlashcardQuestion(
                statement = "If an app looks professional, it is always safe to download.",
                isHack = false,
                explanation = "This is a myth. Fake apps can look professional. Users should check reviews, permissions, developer names, and download from trusted stores."
            ),
            FlashcardQuestion(
                statement = "Updating your apps and phone software can improve security.",
                isHack = true,
                explanation = "This is a real digital safety hack. Updates often fix bugs and security weaknesses."
            )
        )
    }

    var currentScreen by remember { mutableStateOf(AppScreen.WELCOME) }
    var currentQuestionIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<Boolean?>(null) }
    var feedbackMessage by remember { mutableStateOf("") }
    val userAnswers = remember { mutableStateListOf<UserAnswer>() }

    when (currentScreen) {
        AppScreen.WELCOME -> {
            WelcomeScreen(
                onStartClicked = {
                    Log.d("LifeHackMythQuiz", "Start button clicked")
                    currentScreen = AppScreen.QUESTION
                }
            )
        }

        AppScreen.QUESTION -> {
            QuestionScreen(
                questionNumber = currentQuestionIndex + 1,
                totalQuestions = questions.size,
                question = questions[currentQuestionIndex],
                selectedAnswer = selectedAnswer,
                feedbackMessage = feedbackMessage,
                onAnswerSelected = { answer ->
                    if (selectedAnswer == null) {
                        selectedAnswer = answer
                        val isCorrect = answer == questions[currentQuestionIndex].isHack

                        if (isCorrect) {
                            score++
                            feedbackMessage = "Correct! That is a real time-saver."
                        } else {
                            feedbackMessage = "Wrong! That is just an urban myth."
                        }

                        userAnswers.add(
                            UserAnswer(
                                question = questions[currentQuestionIndex],
                                selectedAnswer = answer,
                                isCorrect = isCorrect
                            )
                        )

                        Log.d(
                            "LifeHackMythQuiz",
                            "Question ${currentQuestionIndex + 1} answered. Correct: $isCorrect"
                        )
                    }
                },
                onNextClicked = {
                    if (currentQuestionIndex < questions.lastIndex) {
                        currentQuestionIndex++
                        selectedAnswer = null
                        feedbackMessage = ""
                        Log.d("LifeHackMythQuiz", "Moved to next question")
                    } else {
                        currentScreen = AppScreen.SCORE
                        Log.d("LifeHackMythQuiz", "Quiz completed. Final score: $score")
                    }
                }
            )
        }

        AppScreen.SCORE -> {
            ScoreScreen(
                score = score,
                totalQuestions = questions.size,
                onReviewClicked = {
                    currentScreen = AppScreen.REVIEW
                    Log.d("LifeHackMythQuiz", "Review button clicked")
                },
                onRestartClicked = {
                    currentQuestionIndex = 0
                    score = 0
                    selectedAnswer = null
                    feedbackMessage = ""
                    userAnswers.clear()
                    currentScreen = AppScreen.WELCOME
                    Log.d("LifeHackMythQuiz", "Quiz restarted")
                }
            )
        }

        AppScreen.REVIEW -> {
            ReviewScreen(
                answers = userAnswers,
                onBackToScoreClicked = {
                    currentScreen = AppScreen.SCORE
                }
            )
        }
    }
}

@Composable
fun WelcomeScreen(onStartClicked: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Life Hack or Urban Myth?",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF0F172A)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Test your common sense by deciding whether each statement is a real life hack or just an internet myth.",
                        fontSize = 17.sp,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF475569)
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    Button(
                        onClick = onStartClicked,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Start Quiz", fontSize = 18.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuestionScreen(
    questionNumber: Int,
    totalQuestions: Int,
    question: FlashcardQuestion,
    selectedAnswer: Boolean?,
    feedbackMessage: String,
    onAnswerSelected: (Boolean) -> Unit,
    onNextClicked: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Question $questionNumber of $totalQuestions",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2563EB)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = question.statement,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF0F172A)
                    )

                    Spacer(modifier = Modifier.height(26.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { onAnswerSelected(true) },
                            modifier = Modifier.weight(1f),
                            enabled = selectedAnswer == null
                        ) {
                            Text(text = "Hack")
                        }

                        OutlinedButton(
                            onClick = { onAnswerSelected(false) },
                            modifier = Modifier.weight(1f),
                            enabled = selectedAnswer == null
                        ) {
                            Text(text = "Myth")
                        }
                    }

                    if (feedbackMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(22.dp))

                        Text(
                            text = feedbackMessage,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = if (selectedAnswer == question.isHack) {
                                Color(0xFF16A34A)
                            } else {
                                Color(0xFFDC2626)
                            }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = question.explanation,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF475569)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = onNextClicked,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (questionNumber == totalQuestions) "Finish Quiz" else "Next"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScoreScreen(
    score: Int,
    totalQuestions: Int,
    onReviewClicked: () -> Unit,
    onRestartClicked: () -> Unit
) {
    val percentage = (score.toDouble() / totalQuestions.toDouble()) * 100

    val message = when {
        percentage >= 80 -> "Master Hacker! You can spot myths like a pro."
        percentage >= 50 -> "Good Effort! You know some useful hacks, but keep learning."
        else -> "Stay Safe Online! Some myths can be tricky, so keep practising."
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Quiz Complete!",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "$score / $totalQuestions",
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2563EB)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = message,
                        fontSize = 17.sp,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF475569)
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    Button(
                        onClick = onReviewClicked,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Review Answers")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = onRestartClicked,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Restart Quiz")
                    }
                }
            }
        }
    }
}

@Composable
fun ReviewScreen(
    answers: List<UserAnswer>,
    onBackToScoreClicked: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp)
        ) {
            Text(
                text = "Review Answers",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                answers.forEachIndexed { index, answer ->
                    ReviewCard(
                        number = index + 1,
                        answer = answer
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onBackToScoreClicked,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Back to Score")
            }
        }
    }
}

@Composable
fun ReviewCard(
    number: Int,
    answer: UserAnswer
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Question $number",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2563EB)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = answer.question.statement,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Your answer: ${if (answer.selectedAnswer) "Hack" else "Myth"}",
                fontSize = 15.sp,
                color = Color(0xFF475569)
            )

            Text(
                text = "Correct answer: ${if (answer.question.isHack) "Hack" else "Myth"}",
                fontSize = 15.sp,
                color = Color(0xFF475569)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (answer.isCorrect) "Result: Correct" else "Result: Incorrect",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (answer.isCorrect) Color(0xFF16A34A) else Color(0xFFDC2626)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = answer.question.explanation,
                fontSize = 14.sp,
                color = Color(0xFF475569)
            )
        }
    }
}